"""Mock retriever. Replace retrieve() with vector search later."""
EVIDENCE = {
    'technology': [
        {'id':'tech-1','text':'Demo only: verify exact router model and component compatibility before purchasing.','source':'MOCK_technology.txt','page':1},
        {'id':'tech-2','text':'Demo only: inspect logs, firmware version and environmental alarms before replacing hardware.','source':'MOCK_technology.txt','page':2}],
    'clinical': [
        {'id':'clinical-1','text':'Demo only: instrument selection depends on throughput, supported assays and maintenance requirements.','source':'MOCK_clinical.txt','page':1}],
    'sec': [
        {'id':'sec-1','text':'Demo only: review supplier annual filings and assess operational risks before long-term procurement.','source':'MOCK_sec.txt','page':1}],
    'csr': [
        {'id':'csr-1','text':'Demo only: compare food-security projects by feasibility, cost and measurable impact.','source':'MOCK_csr.txt','page':1}]
}

def retrieve(question: str, domain: str, k: int=3) -> list[dict]:
    """Contract: return evidence items with id,text,source,page. All content is mock."""
    return [dict(item) for item in EVIDENCE.get(domain, [])[:k]]

"""Shared deterministic recommender. Scores and candidates here are MOCK values."""
DEMO = {
 'technology': [
     {'name':'Investigate logs and power events','eligible':True,'scores':{'impact':9,'feasibility':9,'cost':9}},
     {'name':'Validate compatible replacement options','eligible':True,'scores':{'impact':8,'feasibility':7,'cost':6}},
     {'name':'Order unverified router hardware','eligible':False,'scores':{'impact':5,'feasibility':2,'cost':3}}],
 'clinical': [
     {'name':'Verify lab throughput and instrument specifications','eligible':True,'scores':{'impact':9,'feasibility':9,'cost':9}},
     {'name':'Request instrument maintenance and support details','eligible':True,'scores':{'impact':8,'feasibility':8,'cost':8}}],
 'sec': [
     {'name':'Review supplier risk disclosures','eligible':True,'scores':{'impact':9,'feasibility':9,'cost':9}},
     {'name':'Prepare supplier contingency plan','eligible':True,'scores':{'impact':8,'feasibility':7,'cost':6}}],
 'csr': [
     {'name':'Evaluate smart irrigation pilot','eligible':True,'scores':{'impact':9,'feasibility':7,'cost':6}},
     {'name':'Evaluate food-storage improvement pilot','eligible':True,'scores':{'impact':8,'feasibility':8,'cost':7}}]
}
DEFAULT_WEIGHTS={'impact':0.5,'feasibility':0.3,'cost':0.2}

def recommend(candidates: list[dict], criteria: dict[str,float] | None=None) -> list[dict]:
    weights=criteria or DEFAULT_WEIGHTS
    if not weights or sum(weights.values())<=0:
        raise ValueError('Positive recommendation weights required')
    denominator=sum(weights.values())
    results=[]
    for option in candidates:
        if not option.get('eligible',False):
            continue
        scores=option.get('scores',{})
        if any(key not in scores or not isinstance(scores[key],(int,float)) or not 0<=scores[key]<=10 for key in weights):
            continue
        score=sum(scores[key]*weight for key,weight in weights.items())/denominator
        results.append({'name':option['name'],'score':round(score,2),'reason':'Illustrative score using impact, feasibility and cost-effectiveness.','mock':True})
    return sorted(results,key=lambda value:value['score'],reverse=True)

def domain_candidates(domain: str) -> list[dict]:
    return [dict(row) for row in DEMO.get(domain,[])]

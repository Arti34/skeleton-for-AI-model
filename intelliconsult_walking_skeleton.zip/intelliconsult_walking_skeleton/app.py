import streamlit as st
from manager import consult

st.set_page_config(page_title='IntelliConsult AI | Walking Skeleton',page_icon='🧠',layout='wide')
st.title('🧠 IntelliConsult AI')
st.caption('Walking skeleton • MOCK retrieval & recommendations • No LLM or online API')
st.warning('DEMONSTRATION ONLY: All evidence and scores are synthetic placeholders, not factual advice.')
examples={
 'Technology':'Our Cisco router has intermittent network failures. What should we do?',
 'Clinical':'Which Agilent laboratory instrument fits our requirements?',
 'SEC':'What supplier financial risks should we review in the SEC annual report?',
 'CSR':'Which food security or irrigation CSR project should we prioritize?',
 'Cross-domain':'We plan to buy Agilent laboratory instruments. What supplier financial risks should we consider?'
}
choice=st.selectbox('Demo question',list(examples))
question=st.text_area('Customer question',value=examples[choice],height=100)
if st.button('Get consulting recommendation',type='primary'):
    try:
        report=consult(question)
    except ValueError as exc:
        st.error(str(exc))
    else:
        st.session_state['report']=report
if 'report' in st.session_state:
    report=st.session_state['report']
    st.subheader('Selected consultants')
    st.write(' · '.join(agent.title() for agent in report['selected_agents']))
    left,right=st.columns(2)
    with left:
        st.subheader('Findings')
        for value in report['findings']:
            st.write('• '+value)
        st.subheader('Evidence (mock)')
        for item in report['citations']:
            with st.expander(f"{item['domain'].title()}: {item['source']} p. {item['page']}"):
                st.write(item['text'])
    with right:
        st.subheader('Ranked next actions (mock scores)')
        for item in report['recommendations']:
            st.write(f"**{item['domain'].title()} — {item['name']}**: {item['score']}/10")
            st.caption(item['reason'])
        st.subheader('Next actions')
        for item in report['next_actions']:
            st.write('• '+item)
    st.subheader('Uncertainties')
    for value in report['uncertainties']:
        st.write('• '+value)
    with st.expander('Raw response JSON — team integration contract'):
        st.json(report)

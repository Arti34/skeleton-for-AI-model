# IntelliConsult AI — walking skeleton

**This is deliberately a MOCK prototype.** It needs no PDFs, Ollama, LangGraph, FAISS, model training, or online inference. Evidence, ranking inputs and recommendations are illustrative and must not be presented as verified factual results.

## Windows PowerShell quick start

```powershell
cd intelliconsult_walking_skeleton
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m streamlit run app.py
```

Use `py -3.12` instead if your installed Python is 3.12. The app opens at `http://localhost:8501`.

Tests (from the project folder):

```powershell
.\.venv\Scripts\python.exe -m pytest -q
```

## Component contracts and owners

| Owner | File | Public contract | Replace later with |
|---|---|---|---|
| 1 RAG | `rag.py` | `retrieve(question, domain, k=3)` returns `[{'id','text','source','page'}]` | PyMuPDF + Sentence Transformers + FAISS; keep original PDF provenance |
| 2 Agents | `manager.py` | `route(question)` and `consult(question)` | Ollama/Qwen (optional) + more reliable routing; keep report structure |
| 3 Recommender | `recommender.py` | `recommend(candidates, criteria)` | Data-derived candidate list, eligibility rules and validated numeric scoring |
| 4 UI/QA | `app.py`, `tests/` | Calls `consult(question)` and displays returned JSON | Better report visuals, evaluation cases |

`consult()` returns `question`, `selected_agents`, `findings`, `recommendations`, `citations`, `uncertainties`, `next_actions`, `business_kpis`, and `demo_only`.

## Demo questions

The UI includes five choices: Technology, Clinical, SEC, CSR, and Clinical+SEC cross-domain. The keyword router is intentionally simplistic and should not be interpreted as robust intent classification.

## Suggested milestones

- **0–15 min:** Install Python dependencies, launch Streamlit, test 5 questions.
- **15–30 min:** All four members agree on the contracts; make a shared repo.
- **30–90 min:** Replace mock pieces independently.
- **90–120 min:** Integrate and run tests.

## Safety / quality notes

- All sources begin with `MOCK_`. Do **not** present them as professor-supplied citations.
- Scores are illustrative; real recommendation candidates and constraints must be grounded in the provided documents / verified structured tables.
- Never guess hardware compatibility, medical instrument suitability, filings, or supplier prices.
- When uncertain, ask the user for missing requirements or report insufficient evidence.

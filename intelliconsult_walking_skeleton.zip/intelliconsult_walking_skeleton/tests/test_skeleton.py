import pytest
from manager import route, consult
from rag import retrieve
from recommender import recommend

def test_technology_route():
    assert route('Our Cisco router failed')==['technology']

def test_cross_domain_route():
    assert route('Agilent laboratory equipment and supplier financial risks')==['clinical','sec']

def test_retrieval_has_provenance():
    row=retrieve('router','technology')[0]
    assert {'text','source','page','id'} <= row.keys()

def test_recommender_excludes_ineligible():
    options=[{'name':'bad','eligible':False,'scores':{'impact':10}}, {'name':'good','eligible':True,'scores':{'impact':8}}]
    assert [x['name'] for x in recommend(options,{'impact':1})]==['good']

def test_end_to_end_schema():
    result=consult('Which Agilent instrument? Check supplier financial risk')
    assert result['selected_agents']==['clinical','sec']
    assert {'question','selected_agents','findings','recommendations','citations','uncertainties','next_actions','business_kpis'} <= result.keys()
    assert result['demo_only'] is True

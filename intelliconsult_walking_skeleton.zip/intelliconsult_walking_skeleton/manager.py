"""Mock orchestrator. Replace route() and run_agent() implementations independently."""
from rag import retrieve
from recommender import recommend, domain_candidates

DOMAINS=('technology','clinical','sec','csr')
KEYWORDS={
 'technology':('router','cisco','cloud','network','server','ibm','hardware','software'),
 'clinical':('agilent','laboratory','lab ','instrument','diagnostic','chromatograph'),
 'sec':('sec','filing','financial','annual report','supplier risk','company risk','investment risk','business risk'),
 'csr':('csr','food security','sustainability','sustainable','irrigation','food waste','esg')
}

def route(question: str) -> list[str]:
    """Contract: return one or more of four domains, deterministic for demo."""
    q=question.lower()
    matches=[domain for domain,words in KEYWORDS.items() if any(word in q for word in words)]
    return matches or ['technology']

def run_agent(question: str, domain: str) -> dict:
    """Contract: return domain, findings, evidence, ranked recommendations, uncertainties."""
    evidence=retrieve(question,domain)
    ranked=recommend(domain_candidates(domain))
    return {
        'domain':domain,
        'findings':[f'DEMO: {domain.title()} agent retrieved {len(evidence)} mock evidence passage(s).'],
        'evidence':evidence,
        'recommendations':ranked,
        'uncertainties':['Mock documents and mock scores are not verified enterprise facts.'],
        'next_actions':['Replace mock evidence with professor dataset and rerun evaluation.']
    }

def consult(question: str) -> dict:
    if not question or not question.strip():
        raise ValueError('Enter a question')
    selected=route(question)
    outputs=[run_agent(question,domain) for domain in selected]
    return {
      'question':question,
      'selected_agents':selected,
      'findings':[finding for output in outputs for finding in output['findings']],
      'recommendations':[dict(item,domain=output['domain']) for output in outputs for item in output['recommendations']],
      'citations':[dict(evidence,domain=output['domain']) for output in outputs for evidence in output['evidence']],
      'uncertainties':list(dict.fromkeys(u for output in outputs for u in output['uncertainties'])),
      'next_actions':list(dict.fromkeys(a for output in outputs for a in output['next_actions'])),
      'business_kpis':['Decision turnaround time','Evidence coverage'],
      'demo_only':True
    }
